package Dao;

import Stockage.BD;
import model.Produit;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 * La class Admin qui prend 5 variables de champs contient les methodes
 * qui permet au administrateur d'effectuer leur tache c'est a dire ajout ,
 * modification et suppression .Il dispose plusieurs constructeurs
 *
 * */
public class AdminDAO {
    private int id;
    private String nom;//nom admin
    private String prenom;//prenom admin
    private String password;//mot de passe admin
    private String email;//login de connection pour admin
    /**
     * Un constructeur qui prend comme argument l,
     * */
    public AdminDAO(int id,String prenom, String nom, String email, String mdp) {
        this.id=id;
        this.email = email;
        this.nom = nom;
        this.prenom = prenom;
        this.password = mdp;
    }

    /**
     * second constructeur qui prend 4 parametres
     * @param prenom
     * @param nom
     * @param email
     * @param mdp
     */
    public AdminDAO(String prenom, String nom, String email, String mdp) {
        this.email = email;
        this.nom = nom;
        this.prenom = prenom;
        this.password = mdp;
    }

    /**
     * autre constructeur qui prend 1 seul parametre :
     * @param user
     */
    public AdminDAO(String user) {
        this.email = user;
    }
    /**
     * Un constructeur qui prend un argument de type entier ici
     * c'est son id .
     * */
    public AdminDAO(int id) {
        this.id = id;
    }

    /**
     * un contructeur ne prenant pas d'argument
     */
    public AdminDAO() {
    }

    /**
     * On crée  pour chaque attribut un getter et setter
     * */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMdp() {
        return password;
    }

    public void setMdp(String mdp) {
        this.password = mdp;
    }

    /**
     * La méthode ajouterProduit prenant comme argument un objet de type Produit permet d'ajouter un  nouveau
     * enregistrement dans la table produits
     * */
    public void ajouterProduit(Produit produit) {
        Connection conn = BD.GetConnection();//connexion a la base de donnée
        try {
            String sql="SELECT * FROM produits WHERE id=?";
            PreparedStatement stm = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stm.setInt(1, produit.getId());
            ResultSet rs = stm.executeQuery();

            if (rs.next()) {
                System.out.println("Produit existant dans la base de données. Impossible de l'ajouter");
                JOptionPane.showMessageDialog(null, "Impossible d'ajouter le produit car il existe déjà ");
            } else {
                sql="INSERT INTO produits(nom,description,prix) VALUES(?,?,?) ";
                stm = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                stm.setString(1, produit.getNom());
                stm.setString(2, produit.getDescription());
                stm.setFloat(3, produit.getPrix());
                // insertion
                //execution de la requete insertion
                stm.executeUpdate();
                System.out.println("Produit ajouté avec succés...");
                //creation d'un objet de notre boite de dialogue
                JOptionPane.showMessageDialog(null, "Produit ajouté avec succée");
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * La méthode modifier qui prend comme argument un objet de type Produit permet modifier un
     * enregistrement dans la table produits
     * */
    public void modifierProduit(Produit produit) {
        Connection conn = BD.GetConnection();//connexion a la base de donnée
        try {
            String sql="UPDATE produits SET nom =?,description =?,prix=? WHERE id = ?";
            //creation du statement
            PreparedStatement stm = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stm.setString(1, produit.getNom());
            stm.setString(2, produit.getDescription());
            stm.setFloat(3, produit.getPrix());
            stm.setInt(4, produit.getId());
            //execution de la requete update
            stm.executeUpdate();

            System.out.println("Produit modifié avec Succés ...");
            //creation d'une objet de notre boite de dialloge
            JOptionPane.showMessageDialog(null, "Modification réussie");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * La méthode supprimer qui prend un argument de type int permettant supprimer un
     * produit de la table produits
     *
     * */
    public void supprimerProduit(int id) {
        Connection conn = BD.GetConnection();//connexion a la base de donné
        try {
            String sql="DELETE FROM produits WHERE id = ?";
            //creation du statement
            PreparedStatement stm = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stm.setInt(1, id);
            //excution du requuette Delete
            stm.executeUpdate();
            System.out.println("Produit Supprimé avec Succès ...");
            //creation d'une objet de notre boite de dialloge
            JOptionPane.showMessageDialog(null, "Suppression Réussie");

        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
            //creation d'une objet de notre boite de dialloge
            JOptionPane.showMessageDialog(null, "Ajout Réussie");
        }
    }

}

