package views;
import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumnModel;
import Dao.AdminDAO;
import Stockage.BD;
import others.ButtonDelete;
import others.ButtonEdit;
import others.CellCenter;
import others.Table;


/**
 * La class ListeProduits herite de la class JPanel n'a aucun variable de champs
 * Cette classe permet d'afficher la liste des produits
 * */
public class ListeProduits extends javax.swing.JPanel {

    /**
     * Il contient une constructeur sans argument .
     * */
    public ListeProduits() {
        initComponents();
        initProduit();
    }
/**
 * La methode initProduit permet d'initialiser notre JPanel .
 * */
    /**
     * Les elements du tableau seront centrés en creant notre propre model de column, grace
     * à sa methode getColumn qui recupère les colonnes données en argument et la méthode setCellRender
     * qui prend en argument un Renderer ici un objet de notre class CellCenter hérité
     * de la class DefaultTableCellRenderer qui nous permet de centrer nos eléments
     */

    public void initProduit() {
        String[] entete = { "ID", "Nom Produit", "Description", "prix","Modifier","Supprimer"};
        String req = "SELECT * FROM produits ORDER BY id ASC";
        Table table = new Table(entete,entete.length,4,req);
        JTable tab = table.getTable();
        TableColumnModel modele = tab.getColumnModel();
        modele.getColumn(0).setCellRenderer(new CellCenter());
        modele.getColumn(1).setCellRenderer(new CellCenter());
        modele.getColumn(2).setCellRenderer(new CellCenter());
        modele.getColumn(3).setCellRenderer(new CellCenter());
        /**
         * Grace a la méthode setCellRenderer de la class TableColumnModel on a pu
         * ajouter des boutons dans notre tableau . Il prend en argument le button à ajouter
         * qui  doit implementer l'interface TableCellRenderer ici nos deux classes implementant
         * l'interface sont ButtonEdit et ButtonDelete .
         * Pour rendre nos boutons ainsi crées à répondre au évenement, la méthode setCellEditor
         * est utilisée elle prend en argument un cellEditor .
         * */
        modele.getColumn(4).setCellRenderer(new ButtonEdit());
        modele.getColumn(4).setCellEditor(new CellEditorEdit(new JCheckBox()));
        modele.getColumn(5).setCellRenderer(new ButtonDelete());
        modele.getColumn(5).setCellEditor(new CellEditorDelete(new JCheckBox()));
        JScrollPane pan = table.getPane(content.getWidth());
        content.removeAll();
        content.setLayout(new BorderLayout());
        content.add(pan);
        content.revalidate();
    }
    /**
     * La class CellEditorEdit heritant de la class DefaultCellEditor, est un class interne
     * dans la class ListeProduits qui nous permet de crée un bouton  qui nous permet de modifier
     * les enregistrements sur la table produits . Ce bouton sera ajouté sur chaque ligne
     * de notre Liste pour la modification de la ligne concernée . Il contient 6 variables de
     * champs :
     * 		+ Un variable de type JButton qui sera notre bouton,
     * 		+ Un variable de type String qui represente le label qui se trouve sur notre bouton,
     * 		+ UN variable de type boolean qui vas rendre cliquable ou non notre boutton,
     * 		+ Deux variables de type int qui reprente index de colonne et de la ligne
     * 		+ Un JTable
     * */
    public class CellEditorEdit extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean clicked;
        private int row, col;
        private JTable table;
        /**
         * Il exite un seul constructeur pour cette classe qui prend en argument un JCheckBox
         * */
        public CellEditorEdit(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setForeground(Color.black);
            button.setBackground(Color.red);

            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
                                                     int column) {
            this.table = table;
            this.row = row;
            this.col = column;
            button.setForeground(Color.black);
            button.setBackground(Color.red);
            label = (value == null) ? "" : value.toString();
            clicked = true;
            return button;
        }
        /** L'evenement de modification est appelée dans la méthode getCellEditorValue .*/
        public Object getCellEditorValue() {
            if (clicked) {
                // Action au clic de la souris
                edit(Integer.parseInt(table.getValueAt(row, 0).toString()) );
            }
            clicked = false;
            return label;
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
    /**
     * Il en est de meme pour la class CellEditorDelete, sauf que ici on supprime les enregistrements
     * */
    public class CellEditorDelete extends DefaultCellEditor {
        private final JButton button;
        private String label;
        private boolean clicked;
        private int row, col;
        private JTable table;

        public CellEditorDelete(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setForeground(Color.black);
            button.setBackground(Color.red);
            // button.setIcon(new
            // javax.swing.ImageIcon(getClass().getResource("/images/wn.png")));
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
                                                     int column) {
            this.table = table;
            this.row = row;
            this.col = column;
            button.setForeground(Color.black);
            button.setBackground(Color.red);
            // button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ico-delete.png")));
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            clicked = true;
            return button;
        }
        /**
         * L'evenement de suppression est appelée dans la méthode getCellEditorValue .
         * */
        public Object getCellEditorValue() {
            if (clicked) {
                // Action au clic de la souris
                delete(Integer.parseInt(table.getValueAt(row, 0).toString()) );
            }
            clicked = false;
            return label;
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
    /**
     * La methode Edit qui prend en argument un entier permet de modifier les informations
     * un enregistrement . Il est appelé lors du clic sur la boutton édit .
     *
     * */
    public void edit(int str) {
        // traitements
        ProduitEdit pe = new ProduitEdit(new JFrame(), true, str, this);
        pe.setVisible(true);
    }
    /**
     * La methode qui prend en argument un entier permet de supprimer un enregistrement
     * dont son identificateur est donné en paramettre .Cette méthode est appelée lors du clic
     * sur le bouton delete .
     * */
    public void delete(int id) {
        Connection conn = BD.GetConnection();
        try {
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stm.executeQuery("SELECT * FROM produits WHERE id = \"" + id + "\"");
            rs.first();
            String nom = rs.getString("nom");
            int prix = rs.getInt("prix");
            views.UI ui = new views.UI();
            ui.SetRed();
            int valid = JOptionPane.showOptionDialog(
                    null,
                    new Object[] {
                            "Voulez-vous vraiment supprimer ce produit ?",
                            nom + " " + prix,
                            "____________________________________________________",
                            "Cette opération est irreversible",
                            "____________________________________________________",
                            "Cliquez sur \"OUI\" pour valider ou sur \"NON\" pour annuler"
                    },
                    "Suppression du produit " + nom + " " + prix,
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE,
                    null,
                    null,
                    "OK");
            ui.ResetUI();
            if (valid == JOptionPane.OK_OPTION) {
                AdminDAO ad = new AdminDAO(id);
                ad.supprimerProduit(id);
                this.initProduit();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ListeProduits.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     */
    /**
     * La methode initComponents qui n'a pas argument permet d'initialiser notre JPanel
     * */

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel1.setForeground(new Color(255, 255, 255));
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        content = new javax.swing.JPanel();

        jPanel1.setBackground(new Color(0, 0, 128));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Liste des produits");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 675,
                                        Short.MAX_VALUE)
                                .addContainerGap()));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                jPanel1Layout.createSequentialGroup()
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel1)
                                        .addContainerGap()));

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
                contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE));
        contentLayout.setVerticalGroup(
                contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 393, Short.MAX_VALUE));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(content, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap()));
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(content, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap()));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap()));
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel content;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

}
