package model;

/**
 * cette classe sert de modele à notre application
 */
public class Produit {
    //id produit
    private int id;

    // nom produit
    private String nom;

    //description du produit
    private String description;

    //prix du produit
    private float prix;

    /**
     * elle dispose d'un constructeur ayant comme parametres :
     * @param id
     * @param nom
     * @param description
     * @param prix
     */
    public Produit(int id, String nom, String description, int prix) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.prix = prix;
    }

    /**
     * elle dispose également d'un autre constructeur ayant comme parametres
     * @param nom
     * @param description
     * @param prix
     */
    public Produit( String nom, String description, int prix) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
    }

    /**
     * cette methode permet de récuperer l'id du produit
     * @return
     */
    public int getId() {
        return id;
    }
    /**
     * cette methode permet de modifier l'id d'un produit
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * cette methode permet de récuperer le nom du produit
     * @return
     */
    public String getNom() {
        return nom;
    }
    /**
     * cette methode permet de modifier le nom d'un produit
     * @param nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * cette methode permet de récuperer la description du produit
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     * cette methode permet de modifier la description d'un produit
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * cette methode permet de récuperer le prix du produit
     * @return
     */
    public float getPrix() {
        return prix;
    }

    /**
     * cette methode permet de modifier le prix d'un produit
     * @param prix
     */
    public void setPrix(float prix) {
        this.prix = prix;
    }
}
