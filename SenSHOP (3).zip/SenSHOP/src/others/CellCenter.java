package others;

import javax.swing.table.DefaultTableCellRenderer;
/**
 * cette classe permet d'afficher les cellules dans une table
 */
public class CellCenter extends DefaultTableCellRenderer {
    //private static final long serialVersionUID = 1L;
    public CellCenter() {
        setHorizontalAlignment(CENTER);
        setVerticalAlignment(CENTER);
    }
}
