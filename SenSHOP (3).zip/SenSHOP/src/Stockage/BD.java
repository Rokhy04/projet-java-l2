package Stockage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * cette classe permet de gérer la connexion
 */
public class BD{


    //url
    public static final String URL = "jdbc:mysql://localhost:3306/shopYatou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    //utilisateur
    public static final String USER = "root";
    //password
    public static final String PASSWORD = "ibrahima12";
    //driver_jdbc
    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    //instance de notre classe
    private static final BD instance = new BD();

    //Constructeur privé
    private BD() {
        try {
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException ignored) {
        }
    }

    /**
     *
     * cette methode permet de créer la connexion entre le jdbc et la base de donnée
     * 
     **/
    private Connection createConnection() {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to Database.");
            return connection;
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }

    /**
     *  cette methode permet de recupérer la connexion
     * @return 
     **/
    public static Connection GetConnection() {
        return instance.createConnection();
    }

}